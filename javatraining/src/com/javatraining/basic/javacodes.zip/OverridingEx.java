package com.javatraining.basic;

public class OverridingEx extends AbstractEX {
//with the help of overriding concept we can provide implementation of  abstract method
	@Override
	public void add(int a, int b,int c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int a, int b) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(int a, int b) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void get(int a, int b) {
		// TODO Auto-generated method stub
		
	}

}

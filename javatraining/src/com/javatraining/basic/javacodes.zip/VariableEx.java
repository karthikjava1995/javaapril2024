package com.javatraining.basic;

public class VariableEx {
//Datatype variable=Data;
	int age=22;
	double d=7.5;//global variable
	String s="javaclass";
	final int a=37;//constant 
	
	public void run()
	{
	int b=20;//local variable
	
	}
	//Datatype:
	//primitive datatype :it is not a class they are predefined ex; int,float,double,boolean.
	//Non-primitive datatype:it is defined as a class it is also called class type ex; String,Array.
	
}

package com.javatraining.basic;

public class Veg {
	public void wash() {
		System.out.println("Need to wash");

	}

	public void chop() {
		System.out.println("Need to chop");

	}
}

package com.javatraining.basic;

public class Animal1 { // Superclass (parent)
	public void animalSound() 
	{
		System.out.println("The animal makes a sound");
	}
}
   
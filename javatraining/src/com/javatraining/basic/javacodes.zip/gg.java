package com.javatraining.basic;

public class gg {
	void login() {
		System.out.println("login details");
	}
	void password() {
		System.out.println("password details");
	}
}

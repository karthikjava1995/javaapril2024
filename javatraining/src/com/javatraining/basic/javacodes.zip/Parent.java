
package com.javatraining.basic;

public class Parent extends Grandparent
{
	public void house() {
		System.out.println("10000 sqrt fit house");
	}
	public void land() {
		System.out.println("near to high way");
	}

}
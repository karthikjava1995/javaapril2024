package com.javatraining.basic;

public class yy extends gg {
	public void credentials()
	{
		System.out.println("credentials");
	}
public static void main(String[] args)
{
	yy z=new yy();
	z.login();
	z.password();
}
}


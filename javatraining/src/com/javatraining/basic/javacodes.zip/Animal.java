package com.javatraining.basic;

public class Animal

{
	String color = "black";

	public Animal() {
		System.out.println("lion");
	}

	public Animal(String s) {
		System.out.println("Tiger");
	}

}

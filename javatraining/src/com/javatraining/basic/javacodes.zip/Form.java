package com.javatraining.basic;

public class Form {
	public static void main(String[] args) {

		 int id = 101;
		//id=1001;
  		String name = "karthik";
		String company = "cognizant";
		String designation = "software engineer";
		System.out.println("id : " + id);
		System.out.println("name : " + name);
		System.out.println("company : " + company);
		System.out.println("desination: " + designation);
	}
}

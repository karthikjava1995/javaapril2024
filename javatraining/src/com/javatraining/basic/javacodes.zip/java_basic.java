package com.javatraining.basic;
// we have 2 types of datatype - primitive & non primitive
	
//	int = number = short 
//	byte 
//	boolean = true and false
//	float double = 6.0 , 7.1
	
	//Non - primitive datatype
	//String Arrays //Wrapperclass
	
//variable = datatype varibale = value	
	//            int a = 10;
	//       String s = "hello world";
	
//identifier rules: 
	//1. Class name always start with Capital letter
	//2. we can not use space with identifier.
	//3. we can't use special character with identifier apart from _
    //4. Identifier must not be a java keyword 
	//5. identifier have number but we can't start with number
//uzu-zcyn-ezopackage com.javatraining.basic;

public class java_basic {

}

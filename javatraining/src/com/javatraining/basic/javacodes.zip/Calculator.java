package com.javatraining.basic;

public class Calculator {

}

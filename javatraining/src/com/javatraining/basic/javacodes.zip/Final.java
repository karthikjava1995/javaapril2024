package com.javatraining.basic;

public class Final {
	    //final keyword providing restriction to the java data members
		//if we are using final keyword with variable then we can't change the value of variable its behaving like constant.
		//if we are using final keyword with method then we can't override the method.
		//if we are using final keyword with the class we can't extend the property of the class.
}

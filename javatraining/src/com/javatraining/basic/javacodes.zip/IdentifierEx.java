package com.javatraining.basic;

public class IdentifierEx {
    //1.Identifier can't have space
    //2.Identifier can't have special character abstract from '_ and $'
	// 3.Identifier must not be a java keyword
	//4.Identifier  have number but not start with the number
	//5.class name start with caps letter
}

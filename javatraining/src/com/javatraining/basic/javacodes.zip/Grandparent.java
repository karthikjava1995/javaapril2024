package com.javatraining.basic;

public class Grandparent {
	public void gold() {
		System.out.println("100kg gold");
		System.out.println("farm house tiruvannamalai");
	}
}
